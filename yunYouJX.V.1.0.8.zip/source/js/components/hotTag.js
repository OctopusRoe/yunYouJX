/* 热门标签 组件 */

const hotTag = {
  template: `
    <div class="hot-tag-box">
      <div>
        <img src="../source/images/jingdian/hot.png" />
        <p class="m-l-5">热门</p>
      </div>
    </div>
  `
}